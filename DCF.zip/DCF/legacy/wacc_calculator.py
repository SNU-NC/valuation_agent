import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
from typing import Dict, Optional
import os
from dotenv import load_dotenv
from fredapi import Fred

load_dotenv()

class WACCCalculator:
    """WACC(Weighted Average Cost of Capital)를 계산하는 클래스"""
    
    def __init__(self, ticker_symbol: str):
        self.ticker_symbol = ticker_symbol
        self.stock = yf.Ticker(ticker_symbol)
        self.fred = Fred(api_key=os.getenv("FRED_API_KEY"))  # FRED API 초기화
        
    def calculate_wacc(self) -> Dict[str, float]:
        """WACC 계산"""
        try:
            # 자본비용 계산
            cost_of_equity = self._calculate_cost_of_equity()
            
            # 부채비용 계산
            cost_of_debt = self._calculate_cost_of_debt()
            
            # 자본구조 계산
            equity_weight, debt_weight = self._calculate_capital_structure()
            
            # WACC 계산
            wacc = (cost_of_equity * equity_weight) + (cost_of_debt * (1 - self.effective_tax_rate) * debt_weight)
            
            return {
                'WACC': wacc,
                'Cost of Equity': cost_of_equity,
                'Cost of Debt': cost_of_debt,
                'Equity Weight': equity_weight,
                'Debt Weight': debt_weight,
                'Risk-free Rate': self.risk_free_rate,
                'Market Risk Premium': self.market_risk_premium,
                'Beta': self.beta,
                'Effective Tax Rate': self.effective_tax_rate
            }
            
        except Exception as e:
            print(f"WACC 계산 중 오류 발생: {str(e)}")
            return None
    
    def _calculate_cost_of_equity(self) -> float:
        """자본비용 계산 (CAPM 모델 사용)"""
        # 무위험수익률 가져오기 (한국 30년 만기 국채)
        self.risk_free_rate = self._get_risk_free_rate()
        
        # 시장위험프리미엄 계산
        self.market_risk_premium = self._calculate_market_risk_premium()
        
        # 베타 계산
        self.beta = self._search_beta()
        
        # CAPM 모델로 자본비용 계산
        return self.risk_free_rate + (self.beta * self.market_risk_premium)
    
    def _calculate_cost_of_debt(self) -> float:
        """부채비용 계산 (세후 기준)"""
        try:
            # 최근 연간 재무제표 이자비용과 총부채 가져오기
            financials = self.stock.financials
            balance_sheet = self.stock.balance_sheet
            
            interest_expense = abs(financials.loc['Interest Expense'].iloc[1])
            print(f"이자비용: {interest_expense:,.0f}")
            total_debt = balance_sheet.loc['Total Debt'].iloc[1]
            # Interest Expense는 Total Debt에 의한 이자비용.
            # Total Liabilities Net Minority Interest에는 이자를 지급하지 않는 부채도 많이 포함되어 있음.
            # Total Liabilities를 분모로 하여 cost of debt 계산하면 비이성적으로 낮은 값 나옴.
            print(f"부채총계: {total_debt:,.0f}")
            if total_debt == 0:
                return 0
            
            # 실효세율 계산
            self.effective_tax_rate = self._calculate_effective_tax_rate()
            
            # 세전 부채비용 계산
            pretax_cost_of_debt = interest_expense / total_debt
            print(f"세전 부채비용: {pretax_cost_of_debt:.2%}")
            # 세후 부채비용 계산
            cost_of_debt = pretax_cost_of_debt * (1 - self.effective_tax_rate)
            print(f"세후 부채비용: {cost_of_debt:.2%}")
            return cost_of_debt
            
        except Exception:
            return 0.045  # 기본값 4.5%
    
    def _calculate_effective_tax_rate(self) -> float:
        """실효세율 계산"""
        try:
            financials = self.stock.financials
            pretax_keys = ['Pretax Income']
            tax_keys = ['Tax Provision']
            
            # 법인세차감전순이익 찾기
            pretax_income = None
            for key in pretax_keys:
                try:
                    pretax_income = financials.loc[key].iloc[1]
                    break
                except (KeyError, IndexError):
                    continue
                
            # 법인세비용 찾기
            income_tax = None
            for key in tax_keys:
                try:
                    income_tax = abs(financials.loc[key].iloc[1])
                    break
                except (KeyError, IndexError):
                    continue

            print(f"계산된 법인세차감전순이익: {pretax_income}")
            print(f"계산된 법인세비용: {income_tax}")
            
            if pretax_income is None or income_tax is None or pretax_income == 0:
                return 0.22  # 기본 법인세율
            
            effective_tax_rate = income_tax / pretax_income

            print(f"계산된 실효세율: {effective_tax_rate:.2%}")
            # 비정상적인 세율 처리 (0%~100% 범위를 벗어나면 기본값 사용)
            if not (0 <= effective_tax_rate <= 1):
                print(f"계산된 실효세율({effective_tax_rate:.2%})이 비정상적입니다. 기본값을 사용합니다.")
                return 0.22
            
            return effective_tax_rate
            
        except Exception as e:
            print(f"실효세율 계산 중 오류 발생: {str(e)}")
            return 0.22  # 기본 법인세율
    
    def _calculate_capital_structure(self) -> tuple[float, float]:
        """자본구조 계산 (장부가 기준)"""
        try:
            # 재무상태표에서 자본총계와 부채총계 가져오기
            balance_sheet = self.stock.balance_sheet
            
            try:
                # 자본총계 (Total Equity) 찾기
                equity_keys = ['Total Equity Gross Minority Interest']
                total_equity = None
                for key in equity_keys:
                    try:
                        total_equity = float(balance_sheet.loc[key].iloc[0])
                        # print(f"자본총계 키 찾음: {key}")
                        print(f"자본총계: {total_equity:,.0f}")
                        break
                    except (KeyError, IndexError):
                        continue
                
                if total_equity is None:
                    # 재무제표 키 확인을 위한 디버깅
                    print("사용 가능한 재무상태표 항목:")
                    print(balance_sheet.index.tolist())
                    raise KeyError("자본총계를 찾을 수 없습니다.")
                    
                # 부채총계 (Total Debt) 찾기
                debt_keys = ['Total Liabilities Net Minority Interest']
                total_debt = None
                for key in debt_keys:
                    try:
                        total_debt = float(balance_sheet.loc[key].iloc[0])
                        # print(f"부채총계 키 찾음: {key}")
                        print(f"부채총계: {total_debt:,.0f}")
                        break
                    except (KeyError, IndexError):
                        continue
                
                # 유동부채와 비유동부채를 합산하는 대체 방법
                # if total_debt is None:
                #     try:
                #         current_liabilities = float(balance_sheet.loc['Total Current Liabilities'].iloc[0])
                #         non_current_liabilities = float(balance_sheet.loc['Total Non Current Liabilities'].iloc[0])
                #         total_debt = current_liabilities + non_current_liabilities
                #         print("부채총계: 유동부채와 비유동부채 합산으로 계산")
                #         print(f"부채총계: {total_debt:,.0f}")
                #     except (KeyError, IndexError):
                #         raise KeyError("부채총계를 찾을 수 없습니다.")
                
                print(f"자본총계: {total_equity:,.0f}")
                print(f"부채총계: {total_debt:,.0f}")
                
                # 전체 자본 (자본총계 + 부채총계)
                total_value = total_equity + total_debt
                
                # 자본구조 비율 계산
                equity_weight = total_equity / total_value
                debt_weight = total_debt / total_value
                
                print(f"자본비율: {equity_weight:.2%}")
                print(f"부채비율: {debt_weight:.2%}")
                
                return equity_weight, debt_weight
                
            except Exception as e:
                print(f"자본구조 계산 중 세부 오류 발생: {str(e)}")
                raise
                
        except Exception as e:
            print(f"자본구조 계산 중 오류 발생: {str(e)}")
            # 기본값으로 부채비율 50% 가정
            return 0.5, 0.5
    
    def _search_beta(self) -> float:
        """베타 값 조회"""
        try:
            # yfinance에서 직접 베타값 조회
            beta = self.stock.info.get('beta') # 5Y Monthly 
            print(f"yfinance에서 조회한 베타값: {beta}")
            if beta is not None and 0 <= beta <= 10:  # 일반적인 베타 범위 체크
                return beta
            
            # 베타값을 찾을 수 없거나 비정상적인 경우 직접 계산
            print("베타값을 직접 계산합니다.")
            
            # 종목 수익률
            print("종목 수익률 다운로드 시작")
            stock_data = yf.download(self.ticker_symbol, 
                                   start=(datetime.now() - timedelta(days=730)),
                                   end=datetime.now(),
                                   interval='1wk')
            stock_returns = stock_data['Adj Close'].pct_change().dropna()
            print("종목 수익률 다운로드 완료")
            
            # 시장 수익률 (KOSPI)
            print("시장 수익률 다운로드 시작")
            market_data = yf.download('^KS11',
                                    start=(datetime.now() - timedelta(days=730)),
                                    end=datetime.now(),
                                    interval='1wk')
            market_returns = market_data['Adj Close'].pct_change().dropna()
            print("시장 수익률 다운로드 완료")
            
            # 베타 계산
            covariance = np.cov(stock_returns, market_returns)[0][1]
            market_variance = np.var(market_returns)
            
            beta = covariance / market_variance

            print(f"계산된 베타값: {beta:.2f}")
            
            # 비정상적인 베타값 처리
            if not (0 <= beta <= 3):
                print(f"계산된 베타값({beta:.2f})이 비정상적입니다. 기본값을 사용합니다.")
                return 1.0
            
            return beta
            
        except Exception as e:
            print(f"베타 계산 중 오류 발생: {str(e)}")
            return 1.0  # 기본값
    
    def _get_risk_free_rate(self) -> float:
        """무위험수익률 조회 (미국 10년 만기 국채)"""
        try:
            # 현재 시점의 미국 10년 국채 수익률 조회 (FRED API 사용)
            # 시장 위험 프리미엄을 계산하는 데에 미국 10년 국채 수익률 사용했으므로, 무위험수익률에도 미국 10년 국채 사용.
            # DGS10: 10-Year Treasury Constant Maturity Rate
            end_date = datetime.now()
            start_date = end_date - timedelta(days=5)  # 최근 5일간의 데이터
            
            treasury_data = self.fred.get_series('DGS10', 
                                               start_date=start_date,
                                               end_date=end_date)
            
            # 가장 최근 데이터 사용
            risk_free_rate = float(treasury_data.dropna().iloc[-1]) / 100
            print(f"현재 미국 10년 국채 수익률: {risk_free_rate:.2%}")
            
            return risk_free_rate
            
        except Exception as e:
            print(f"무위험수익률 조회 중 오류 발생: {str(e)}")
            return 0.035  # 기본값 3.5% TODO: 추후 수정
    
    def _calculate_market_risk_premium(self) -> float:
        """시장위험프리미엄 계산 (S&P 500 기준, 10년)"""
        try:
            # 날짜 설정
            end_date = datetime.now()
            start_date = end_date - timedelta(days=3650)  # 10년
            
            # 시작일과 종료일의 S&P 500 데이터 가져오기
            sp500_start = yf.download('^GSPC',  # S&P 500 지수
                                    start=start_date,
                                    end=start_date + timedelta(days=5),
                                    interval='1d')
            
            sp500_end = yf.download('^GSPC',
                                  start=end_date - timedelta(days=5),
                                  end=end_date,
                                  interval='1d')
            
            # 각 기간의 마지막 거래일 종가 사용
            start_price = float(sp500_start['Adj Close'].iloc[-1].iloc[0])
            end_price = float(sp500_end['Adj Close'].iloc[-1].iloc[0])
            
            print(f"S&P 500 start_price: {start_price}")
            print(f"S&P 500 end_price: {end_price}")

            # 10년 annualized return 계산
            market_return = (end_price / start_price) ** (1/10) - 1
            
            print(f"S&P 500 10년 annualized return: {market_return:.2%}")
            
            # 10년 전 시점의 미국 국고채 10년물 금리 조회 (FRED API 사용)
            # DGS10: 10-Year Treasury Constant Maturity Rate
            treasury_data = self.fred.get_series('DGS10', 
                                               start_date=start_date,
                                               end_date=start_date + timedelta(days=30))
            
            # 해당 기간의 첫 번째 유효한 데이터 사용
            historical_rf = float(treasury_data.dropna().iloc[0]) / 100
            print(f"10년 전 미국 국고채 10년물 금리: {historical_rf:.2%}")
            
            # 시장위험프리미엄 계산
            market_risk_premium = market_return - historical_rf
            print(f"계산된 시장위험프리미엄: {market_risk_premium:.2%}")
            
            # 비정상적인 값 처리 (0% ~ 20% 범위)
            if not (0 <= market_risk_premium <= 0.2):
                print(f"계산된 시장위험프리미엄({market_risk_premium:.2%})이 비정상적입니다. 기본값을 사용합니다.")
                return 0.06
            
            return market_risk_premium
            
        except Exception as e:
            print(f"시장위험프리미엄 계산 중 오류 발생: {str(e)}")
            return 0.06  # 기본값 6%

# 사용 예시
if __name__ == "__main__":
    calculator = WACCCalculator("005930.KS")  # 삼성전자
    results = calculator.calculate_wacc()
    
    if results:
        print("\nWACC 계산 결과:")
        for key, value in results.items():
            # 모든 숫자 타입을 처리
            if isinstance(value, (np.ndarray, np.float64, np.float32, float)):
                if key == "Beta":
                    print(f"{key}: {value:.2f}")
                else:
                    print(f"{key}: {value:.2%}")
            else:
                print(f"{key}: {value}")
