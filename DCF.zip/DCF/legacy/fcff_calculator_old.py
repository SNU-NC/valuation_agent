import pandas as pd
from typing import Dict
from ..DCF.collectors.financial_data_collector import FinancialDataCollector

class FCFFCalculator:
    """FCFF를 계산하는 클래스"""
    
    def __init__(self, ticker_symbol: str):
        self.collector = FinancialDataCollector(ticker_symbol)
    
    def calculate_fcff(self, period: str = "annual") -> pd.DataFrame:
        """FCFF를 계산하는 메서드"""
        try:
            # 재무 지표 수집
            metrics = self.collector.get_financial_metrics(period)
            
            # Working Capital 계산
            working_capital = metrics['current_assets'] - metrics['current_liabilities']
            
            # FCFF 계산
            fcff = (metrics['ebitda'] - 
                   metrics['tax_provision'] - 
                   (metrics['capital_expenditure'] + 
                    (working_capital - metrics['cash_and_equivalents'])))
            
            # 결과 데이터프레임 생성
            results = pd.DataFrame({
                'EBITDA': metrics['ebitda'],
                'Tax Provision': metrics['tax_provision'],
                'Capital Expenditure': metrics['capital_expenditure'],
                'Working Capital': working_capital,
                'Cash and Equivalents': metrics['cash_and_equivalents'],
                'FCFF': fcff
            })
            
            return results
            
        except Exception as e:
            print(f"오류 발생: {str(e)}")
            return None

def calculate_fcff(ticker_symbol: str, period: str = "annual") -> pd.DataFrame:
    """편의를 위한 함수형 인터페이스"""
    calculator = FCFFCalculator(ticker_symbol)
    return calculator.calculate_fcff(period)

# 사용 예시
if __name__ == "__main__":
    ticker = "AAPL"
    fcff_results = calculate_fcff(ticker)
    
    if fcff_results is not None:
        print(f"\n{ticker}의 FCFF 계산 결과:")
        print(fcff_results) 